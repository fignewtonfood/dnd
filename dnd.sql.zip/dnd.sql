-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 29, 2015 at 08:25 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dnd`
--
CREATE DATABASE IF NOT EXISTS `dnd` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `dnd`;

-- --------------------------------------------------------

--
-- Table structure for table `adventure`
--

CREATE TABLE IF NOT EXISTS `adventure` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8,
  `campaign_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `adventure_location`
--

CREATE TABLE IF NOT EXISTS `adventure_location` (
  `id` int(11) NOT NULL,
  `adventure_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `adventure_npc`
--

CREATE TABLE IF NOT EXISTS `adventure_npc` (
  `id` int(11) NOT NULL,
  `adventure_id` int(11) DEFAULT NULL,
  `npc_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `campaign`
--

CREATE TABLE IF NOT EXISTS `campaign` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8,
  `gm_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `character`
--

CREATE TABLE IF NOT EXISTS `character` (
  `id` int(11) NOT NULL,
  `race_id` int(11) DEFAULT NULL,
  `description_id` int(11) DEFAULT NULL,
  `stat_id` int(11) DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `character_class`
--

CREATE TABLE IF NOT EXISTS `character_class` (
  `id` int(11) NOT NULL,
  `character_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `character_equipment`
--

CREATE TABLE IF NOT EXISTS `character_equipment` (
  `id` int(11) NOT NULL,
  `character_id` int(11) DEFAULT NULL,
  `equipment_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `character_spell`
--

CREATE TABLE IF NOT EXISTS `character_spell` (
  `id` int(11) NOT NULL,
  `character_id` int(11) DEFAULT NULL,
  `spell_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `character_weapon`
--

CREATE TABLE IF NOT EXISTS `character_weapon` (
  `id` int(11) NOT NULL,
  `character_id` int(11) DEFAULT NULL,
  `weapon_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `description`
--

CREATE TABLE IF NOT EXISTS `description` (
  `id` int(11) NOT NULL,
  `gender` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `alignment` int(11) DEFAULT NULL,
  `height` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `eye_color` int(11) DEFAULT NULL,
  `hair_color` int(11) DEFAULT NULL,
  `skin_tone` int(11) DEFAULT NULL,
  `other` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE IF NOT EXISTS `equipment` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `gm`
--

CREATE TABLE IF NOT EXISTS `gm` (
  `id` int(11) NOT NULL,
  `sign_in_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8,
  `campaign_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `npc`
--

CREATE TABLE IF NOT EXISTS `npc` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8,
  `campaign_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE IF NOT EXISTS `player` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `sign_in_id` int(11) DEFAULT NULL,
  `character_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `player_campaign`
--

CREATE TABLE IF NOT EXISTS `player_campaign` (
  `id` int(11) NOT NULL,
  `player_id` int(11) DEFAULT NULL,
  `campaign_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `race`
--

CREATE TABLE IF NOT EXISTS `race` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `sign_in`
--

CREATE TABLE IF NOT EXISTS `sign_in` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `spell`
--

CREATE TABLE IF NOT EXISTS `spell` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8,
  `school` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `component` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `range` int(11) DEFAULT NULL,
  `time_to_cast` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `duration` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `stat`
--

CREATE TABLE IF NOT EXISTS `stat` (
  `id` int(11) NOT NULL,
  `str` int(11) DEFAULT NULL,
  `dex` int(11) DEFAULT NULL,
  `con` int(11) DEFAULT NULL,
  `int` int(11) DEFAULT NULL,
  `wis` int(11) DEFAULT NULL,
  `cha` int(11) DEFAULT NULL,
  `initiative` int(11) DEFAULT NULL,
  `max_hp` int(11) DEFAULT NULL,
  `ac` int(11) DEFAULT NULL,
  `speed` int(11) DEFAULT NULL,
  `proficiency` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `weapon`
--

CREATE TABLE IF NOT EXISTS `weapon` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `base_damage` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `damage_type` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `special_attributes` mediumtext CHARACTER SET utf8,
  `description` mediumtext CHARACTER SET utf8,
  `range` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adventure`
--
ALTER TABLE `adventure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `campaign_id` (`campaign_id`);

--
-- Indexes for table `adventure_location`
--
ALTER TABLE `adventure_location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `adventure_id` (`adventure_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `adventure_npc`
--
ALTER TABLE `adventure_npc`
  ADD PRIMARY KEY (`id`),
  ADD KEY `adventure_id` (`adventure_id`),
  ADD KEY `npc_id` (`npc_id`);

--
-- Indexes for table `campaign`
--
ALTER TABLE `campaign`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gm_id` (`gm_id`);

--
-- Indexes for table `character`
--
ALTER TABLE `character`
  ADD PRIMARY KEY (`id`),
  ADD KEY `race_id` (`race_id`),
  ADD KEY `description_id` (`description_id`),
  ADD KEY `stat_id` (`stat_id`);

--
-- Indexes for table `character_class`
--
ALTER TABLE `character_class`
  ADD PRIMARY KEY (`id`),
  ADD KEY `character_id` (`character_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `character_equipment`
--
ALTER TABLE `character_equipment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `character_id` (`character_id`),
  ADD KEY `equipment_id` (`equipment_id`);

--
-- Indexes for table `character_spell`
--
ALTER TABLE `character_spell`
  ADD PRIMARY KEY (`id`),
  ADD KEY `character_id` (`character_id`),
  ADD KEY `spell_id` (`spell_id`);

--
-- Indexes for table `character_weapon`
--
ALTER TABLE `character_weapon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `character_id` (`character_id`),
  ADD KEY `weapon_id` (`weapon_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `description`
--
ALTER TABLE `description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gm`
--
ALTER TABLE `gm`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sign_in_id` (`sign_in_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `campaign_id` (`campaign_id`);

--
-- Indexes for table `npc`
--
ALTER TABLE `npc`
  ADD PRIMARY KEY (`id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sign_in_id` (`sign_in_id`),
  ADD KEY `character_id` (`character_id`);

--
-- Indexes for table `player_campaign`
--
ALTER TABLE `player_campaign`
  ADD PRIMARY KEY (`id`),
  ADD KEY `player_id` (`player_id`),
  ADD KEY `campaign_id` (`campaign_id`);

--
-- Indexes for table `race`
--
ALTER TABLE `race`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign_in`
--
ALTER TABLE `sign_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `spell`
--
ALTER TABLE `spell`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stat`
--
ALTER TABLE `stat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `weapon`
--
ALTER TABLE `weapon`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adventure`
--
ALTER TABLE `adventure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adventure_location`
--
ALTER TABLE `adventure_location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adventure_npc`
--
ALTER TABLE `adventure_npc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `campaign`
--
ALTER TABLE `campaign`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `character`
--
ALTER TABLE `character`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `character_class`
--
ALTER TABLE `character_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `character_equipment`
--
ALTER TABLE `character_equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `character_spell`
--
ALTER TABLE `character_spell`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `character_weapon`
--
ALTER TABLE `character_weapon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `description`
--
ALTER TABLE `description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gm`
--
ALTER TABLE `gm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `npc`
--
ALTER TABLE `npc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `player_campaign`
--
ALTER TABLE `player_campaign`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `race`
--
ALTER TABLE `race`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sign_in`
--
ALTER TABLE `sign_in`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `spell`
--
ALTER TABLE `spell`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stat`
--
ALTER TABLE `stat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `weapon`
--
ALTER TABLE `weapon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `adventure`
--
ALTER TABLE `adventure`
  ADD CONSTRAINT `adventure_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaign` (`id`);

--
-- Constraints for table `adventure_location`
--
ALTER TABLE `adventure_location`
  ADD CONSTRAINT `adventure_location_ibfk_1` FOREIGN KEY (`adventure_id`) REFERENCES `adventure` (`id`),
  ADD CONSTRAINT `adventure_location_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`);

--
-- Constraints for table `adventure_npc`
--
ALTER TABLE `adventure_npc`
  ADD CONSTRAINT `adventure_npc_ibfk_1` FOREIGN KEY (`adventure_id`) REFERENCES `adventure` (`id`),
  ADD CONSTRAINT `adventure_npc_ibfk_2` FOREIGN KEY (`npc_id`) REFERENCES `npc` (`id`);

--
-- Constraints for table `campaign`
--
ALTER TABLE `campaign`
  ADD CONSTRAINT `campaign_ibfk_1` FOREIGN KEY (`id`) REFERENCES `npc` (`id`),
  ADD CONSTRAINT `campaign_ibfk_2` FOREIGN KEY (`gm_id`) REFERENCES `gm` (`id`),
  ADD CONSTRAINT `campaign_ibfk_3` FOREIGN KEY (`id`) REFERENCES `npc` (`id`),
  ADD CONSTRAINT `campaign_ibfk_4` FOREIGN KEY (`gm_id`) REFERENCES `gm` (`id`),
  ADD CONSTRAINT `campaign_ibfk_5` FOREIGN KEY (`id`) REFERENCES `npc` (`id`),
  ADD CONSTRAINT `campaign_ibfk_6` FOREIGN KEY (`gm_id`) REFERENCES `gm` (`id`);

--
-- Constraints for table `character`
--
ALTER TABLE `character`
  ADD CONSTRAINT `character_ibfk_1` FOREIGN KEY (`id`) REFERENCES `campaign` (`id`),
  ADD CONSTRAINT `character_ibfk_2` FOREIGN KEY (`race_id`) REFERENCES `race` (`id`),
  ADD CONSTRAINT `character_ibfk_3` FOREIGN KEY (`description_id`) REFERENCES `description` (`id`),
  ADD CONSTRAINT `character_ibfk_4` FOREIGN KEY (`stat_id`) REFERENCES `stat` (`id`);

--
-- Constraints for table `character_class`
--
ALTER TABLE `character_class`
  ADD CONSTRAINT `character_class_ibfk_1` FOREIGN KEY (`character_id`) REFERENCES `character` (`id`),
  ADD CONSTRAINT `character_class_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `class` (`id`);

--
-- Constraints for table `character_equipment`
--
ALTER TABLE `character_equipment`
  ADD CONSTRAINT `character_equipment_ibfk_1` FOREIGN KEY (`character_id`) REFERENCES `character` (`id`),
  ADD CONSTRAINT `character_equipment_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`);

--
-- Constraints for table `character_spell`
--
ALTER TABLE `character_spell`
  ADD CONSTRAINT `character_spell_ibfk_1` FOREIGN KEY (`character_id`) REFERENCES `character` (`id`),
  ADD CONSTRAINT `character_spell_ibfk_2` FOREIGN KEY (`spell_id`) REFERENCES `spell` (`id`);

--
-- Constraints for table `character_weapon`
--
ALTER TABLE `character_weapon`
  ADD CONSTRAINT `character_weapon_ibfk_1` FOREIGN KEY (`character_id`) REFERENCES `character` (`id`),
  ADD CONSTRAINT `character_weapon_ibfk_2` FOREIGN KEY (`weapon_id`) REFERENCES `weapon` (`id`);

--
-- Constraints for table `gm`
--
ALTER TABLE `gm`
  ADD CONSTRAINT `gm_ibfk_1` FOREIGN KEY (`sign_in_id`) REFERENCES `sign_in` (`id`);

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `location_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaign` (`id`),
  ADD CONSTRAINT `location_ibfk_2` FOREIGN KEY (`campaign_id`) REFERENCES `campaign` (`id`),
  ADD CONSTRAINT `location_ibfk_3` FOREIGN KEY (`campaign_id`) REFERENCES `campaign` (`id`);

--
-- Constraints for table `npc`
--
ALTER TABLE `npc`
  ADD CONSTRAINT `npc_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`);

--
-- Constraints for table `player`
--
ALTER TABLE `player`
  ADD CONSTRAINT `player_ibfk_1` FOREIGN KEY (`sign_in_id`) REFERENCES `sign_in` (`id`),
  ADD CONSTRAINT `player_ibfk_2` FOREIGN KEY (`character_id`) REFERENCES `character` (`id`),
  ADD CONSTRAINT `player_ibfk_3` FOREIGN KEY (`sign_in_id`) REFERENCES `sign_in` (`id`),
  ADD CONSTRAINT `player_ibfk_4` FOREIGN KEY (`character_id`) REFERENCES `character` (`id`),
  ADD CONSTRAINT `player_ibfk_5` FOREIGN KEY (`sign_in_id`) REFERENCES `sign_in` (`id`),
  ADD CONSTRAINT `player_ibfk_6` FOREIGN KEY (`character_id`) REFERENCES `character` (`id`);

--
-- Constraints for table `player_campaign`
--
ALTER TABLE `player_campaign`
  ADD CONSTRAINT `player_campaign_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `player` (`id`),
  ADD CONSTRAINT `player_campaign_ibfk_2` FOREIGN KEY (`campaign_id`) REFERENCES `campaign` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
