-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Sep 01, 2015 at 09:45 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dnd`
--

-- --------------------------------------------------------

--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
CREATE TABLE IF NOT EXISTS `stats` (
  `id` int(11) NOT NULL,
  `str` int(11) DEFAULT NULL,
  `dex` int(11) DEFAULT NULL,
  `con` int(11) DEFAULT NULL,
  `intel` int(11) DEFAULT NULL,
  `wis` int(11) DEFAULT NULL,
  `cha` int(11) DEFAULT NULL,
  `init` int(11) DEFAULT NULL,
  `max_hp` int(11) DEFAULT NULL,
  `ac` int(11) DEFAULT NULL,
  `speed` int(11) DEFAULT NULL,
  `acrobatics` int(11) DEFAULT NULL,
  `arcana` int(11) DEFAULT NULL,
  `animal_handling` int(11) DEFAULT NULL,
  `athletics` int(11) DEFAULT NULL,
  `deception` int(11) DEFAULT NULL,
  `history` int(11) DEFAULT NULL,
  `insight` int(11) DEFAULT NULL,
  `intimidation` int(11) DEFAULT NULL,
  `investigation` int(11) DEFAULT NULL,
  `medicine` int(11) DEFAULT NULL,
  `nature` int(11) DEFAULT NULL,
  `perception` int(11) DEFAULT NULL,
  `performance` int(11) DEFAULT NULL,
  `persuasion` int(11) DEFAULT NULL,
  `religion` int(11) DEFAULT NULL,
  `sleight_of_hand` int(11) DEFAULT NULL,
  `stealth` int(11) DEFAULT NULL,
  `survival` int(11) DEFAULT NULL,
  `proficiency` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stats`
--
ALTER TABLE `stats`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stats`
--
ALTER TABLE `stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
